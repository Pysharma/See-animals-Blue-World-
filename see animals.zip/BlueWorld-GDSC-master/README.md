# BlueWorld-GDSC

A new Flutter project.

This is a flutter project based on the sustainable goal 14 life below water . The aim of this project is to that people should aware of sea animals they know the measures we take to protect the ocean from pollution and people should know about the some of  beautiful creatures are there in the ocean ...
It is in progress..

An OverView.

<p>
  <img src = "https://user-images.githubusercontent.com/98549505/160855446-b3c0e3c0-d46d-481f-b2f2-61c9575ccf41.jpg" width="210" height = "400" /> 
  `
  <img  src = "https://user-images.githubusercontent.com/98549505/160855011-c60a8810-f373-4169-b5d3-987cb90035c0.jpg" width="210" height = "400" />
  `
  <img  src = "https://user-images.githubusercontent.com/98549505/160869671-33958416-d848-459b-aed9-30f31d33d0d6.jpg" width="210" height = "400" />
  <br>
  <br>
  <br>
  <img  src = "https://user-images.githubusercontent.com/98549505/160874911-bc0ffe3e-dcd3-4345-b92c-ea49804691c8.jpg" width="210" height = "400" />
  `
  <img  src = "https://user-images.githubusercontent.com/98549505/160878721-ff461c59-501d-461d-8f51-29dc2daa3d77.jpg" width="210" height = "400" />


  
</p>



## Getting Started

This project is a starting point for a Flutter application.

A few resources to get you started if this is your first Flutter project:

- [Lab: Write your first Flutter app](https://flutter.dev/docs/get-started/codelab)
- [Cookbook: Useful Flutter samples](https://flutter.dev/docs/cookbook)

For help getting started with Flutter, view our
[online documentation](https://flutter.dev/docs), which offers tutorials,
samples, guidance on mobile development, and a full API reference.
