class Strings{
  Strings._();

  static const String APP_NAME = "Blue World ~~~";
  static const String TAG_LINE = "|| Safe Water safe world ||";
  static const String INFO_LINE = " :: Aquatic Life ::";
  static const String NEXT_PAGE = "            click to next.";
  static const String chooseAPlan = "Sea Life";
  static const String welcome = "Welcome To Blue World";
  static const String lifebelow = "** Life Below Water **";
  static const String lifesplash = " Life Below Water ";
  static const String qwickline = "Categories";
  static const String mesuretake = "MEASURE's WE CAN TAKE TO REDUCE SEA POLLUTION..";

}